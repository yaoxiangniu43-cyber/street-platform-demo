1) 在 Windows 上创建 ZIP：
 - 选中整个 street-platform-project 文件夹，右键 -> 发送到 -> 压缩(zipped)文件夹
 - 得到 street-platform-project.zip（你可以把这个 zip 上传给我或直接上传到 GitHub）

2) 在 GitHub 上创建两个仓库：
 - 前端：street-platform-demo
 - 后端：street-platform-server

3) 上传前端（GitHub Pages）：
 - 登录 GitHub -> New repository -> 候选名 street-platform-demo -> Create repository
 - 进入仓库 -> Add file -> Upload files -> 上传 web/index.html -> Commit
 - Settings -> Pages -> Source: main / root -> Save
 - 访问：https://<你的用户名>.github.io/street-platform-demo/

4) 上传后端：
 - 登录 GitHub -> New repository -> street-platform-server -> Create
 - 上传 server/ 目录下文件 -> Commit
 - 如果你要在服务器上运行，用 docker 或 node 部署（见 server/README.md）

5) 替换占位：
 - web/index.html: YOUR_AMAP_KEY 替换为高德 JSAPI Key
 - 后端部署时请使用真实 DB 与 HTTPS / WSS（小程序和线上页面均需 https）
